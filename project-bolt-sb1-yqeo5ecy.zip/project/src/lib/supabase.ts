import { createClient, type SupabaseClient } from '@supabase/supabase-js';

// ─────────────────────────────────────────────────────────────
// HYBRID DATA LAYER
// Uses Supabase when env keys are present, otherwise falls back
// to a rich localStorage-backed engine — zero crash guarantee.
// ─────────────────────────────────────────────────────────────

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const hasSupabase = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase: SupabaseClient | null = hasSupabase
  ? createClient(supabaseUrl!, supabaseAnonKey!)
  : null;

// ─────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────

export type AuthRole = 'free_brand' | 'pro_brand' | 'creator' | 'admin';

export type AuthUser = {
  id: string;
  email: string;
  fullName: string;
  role: AuthRole;
  venueName?: string;
  pincode?: string;
  phone?: string;
};

export type NewCreator = {
  id: string;
  name: string;
  category: string;
  platform: string;
  gender: string;
  pincode: string;
  area: string;
  followers: string;
  rate: string;
  rating: number;
  img: string;
  verified: boolean;
};

export type ShortlistEntry = {
  id: string;
  creatorId: string;
  creatorName: string;
  createdAt: string;
};

export type InviteEntry = {
  id: string;
  venueName: string;
  venuePincode: string;
  creatorId: string;
  creatorName: string;
  packageSelected: string;
  shootDate: string;
  budget: string;
  message: string;
  status: 'pending' | 'accepted' | 'completed';
  createdAt: string;
};

export type UpiLog = {
  id: string;
  brandName: string;
  brandPhone: string;
  planTier: string;
  amount: number;
  utrNumber: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
};

// ─────────────────────────────────────────────────────────────
// LOCAL STORAGE FALLBACK KEYS
// ─────────────────────────────────────────────────────────────

const LS = {
  user: 'krolab_user',
  creators: 'krolab_creators',
  shortlist: 'krolab_shortlist',
  invites: 'krolab_invites',
  upiLogs: 'krolab_upi_logs',
};

function lsGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch { return fallback; }
}

function lsSet<T>(key: string, val: T): void {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* ignore */ }
}

function uid(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

// ─────────────────────────────────────────────────────────────
// AUTH SERVICE
// ─────────────────────────────────────────────────────────────

export const authService = {
  async signUp(email: string, password: string, fullName: string, role: AuthRole, extra?: { venueName?: string; pincode?: string; phone?: string }): Promise<AuthUser> {
    if (supabase) {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName, role } },
      });
      if (error) throw new Error(error.message);
      const userId = data.user?.id ?? uid();
      // Insert profile
      await supabase.from('profiles').upsert({
        id: userId,
        email,
        full_name: fullName,
        role,
        venue_name: extra?.venueName,
        pincode: extra?.pincode,
        phone: extra?.phone,
      });
      return { id: userId, email, fullName, role, venueName: extra?.venueName, pincode: extra?.pincode, phone: extra?.phone };
    }
    // localStorage fallback
    const user: AuthUser = { id: uid(), email, fullName, role, venueName: extra?.venueName, pincode: extra?.pincode, phone: extra?.phone };
    lsSet(LS.user, user);
    return user;
  },

  async signIn(email: string, password: string): Promise<AuthUser> {
    if (supabase) {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw new Error(error.message);
      const userId = data.user?.id ?? uid();
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
      return {
        id: userId,
        email: data.user?.email ?? email,
        fullName: profile?.full_name ?? data.user?.user_metadata?.full_name ?? '',
        role: (profile?.role as AuthRole) ?? 'free_brand',
        venueName: profile?.venue_name,
        pincode: profile?.pincode,
        phone: profile?.phone,
      };
    }
    const stored = lsGet<AuthUser | null>(LS.user, null);
    if (stored && stored.email === email) return stored;
    // Demo: accept any email in fallback mode
    const user: AuthUser = { id: uid(), email, fullName: email.split('@')[0], role: 'free_brand' };
    lsSet(LS.user, user);
    return user;
  },

  async signOut(): Promise<void> {
    if (supabase) { await supabase.auth.signOut(); }
    try { localStorage.removeItem(LS.user); } catch { /* ignore */ }
  },

  async getCurrentUser(): Promise<AuthUser | null> {
    if (supabase) {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return null;
      const userId = session.user.id;
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
      return {
        id: userId,
        email: session.user.email ?? '',
        fullName: profile?.full_name ?? session.user.user_metadata?.full_name ?? '',
        role: (profile?.role as AuthRole) ?? 'free_brand',
        venueName: profile?.venue_name,
        pincode: profile?.pincode,
        phone: profile?.phone,
      };
    }
    return lsGet<AuthUser | null>(LS.user, null);
  },
};

// ─────────────────────────────────────────────────────────────
// CREATOR PORTFOLIO SERVICE
// ─────────────────────────────────────────────────────────────

export const portfolioService = {
  async publishCreator(data: NewCreator): Promise<NewCreator> {
    if (supabase) {
      const { data: row, error } = await supabase.from('creator_portfolios').insert({
        user_id: (await authService.getCurrentUser())?.id,
        name: data.name,
        category: data.category,
        platform: data.platform,
        gender: data.gender,
        pincode: data.pincode,
        area: data.area,
        followers: data.followers,
        base_rate: data.rate,
        avatar_url: data.img,
        verified: false,
      }).select().single();
      if (error) throw new Error(error.message);
      return data; // return the original shape for UI consistency
    }
    const list = lsGet<NewCreator[]>(LS.creators, []);
    list.push(data);
    lsSet(LS.creators, list);
    return data;
  },

  async listCreators(): Promise<NewCreator[]> {
    if (supabase) {
      const { data, error } = await supabase.from('creator_portfolios').select('*').eq('verified', true);
      if (error) return [];
      return (data ?? []).map(r => ({
        id: r.id, name: r.name, category: r.category, platform: r.platform,
        gender: r.gender ?? 'male', pincode: r.pincode, area: r.area ?? '',
        followers: r.followers ?? '0', rate: r.base_rate, rating: 4.8,
        img: r.avatar_url ?? '', verified: r.verified,
      }));
    }
    return lsGet<NewCreator[]>(LS.creators, []);
  },
};

// ─────────────────────────────────────────────────────────────
// SHORTLIST SERVICE
// ─────────────────────────────────────────────────────────────

export const shortlistService = {
  async list(): Promise<ShortlistEntry[]> {
    if (supabase) {
      const { data, error } = await supabase.from('creator_shortlists').select('*').order('created_at', { ascending: false });
      if (error) return lsGet<ShortlistEntry[]>(LS.shortlist, []);
      return (data ?? []).map(r => ({ id: r.id, creatorId: r.creator_id, creatorName: r.creator_name, createdAt: r.created_at }));
    }
    return lsGet<ShortlistEntry[]>(LS.shortlist, []);
  },

  async toggle(creatorId: string, creatorName: string): Promise<void> {
    if (supabase) {
      const existing = await this.list();
      const found = existing.find(e => e.creatorId === creatorId);
      if (found) {
        await supabase.from('creator_shortlists').delete().eq('id', found.id);
      } else {
        await supabase.from('creator_shortlists').insert({ creator_id: creatorId, creator_name: creatorName });
      }
      return;
    }
    const list = lsGet<ShortlistEntry[]>(LS.shortlist, []);
    const idx = list.findIndex(e => e.creatorId === creatorId);
    if (idx >= 0) { list.splice(idx, 1); }
    else { list.unshift({ id: uid(), creatorId, creatorName, createdAt: new Date().toISOString() }); }
    lsSet(LS.shortlist, list);
  },
};

// ─────────────────────────────────────────────────────────────
// INVITE SERVICE
// ─────────────────────────────────────────────────────────────

export const inviteService = {
  async list(): Promise<InviteEntry[]> {
    if (supabase) {
      const { data, error } = await supabase.from('collaboration_invites').select('*').order('created_at', { ascending: false });
      if (error) return lsGet<InviteEntry[]>(LS.invites, []);
      return (data ?? []).map(r => ({
        id: r.id, venueName: r.venue_name, venuePincode: r.venue_pincode ?? '',
        creatorId: r.creator_id, creatorName: r.creator_name,
        packageSelected: r.package_selected ?? '', shootDate: r.shoot_date ?? '',
        budget: r.budget ?? '', message: r.message ?? '',
        status: r.status as InviteEntry['status'], createdAt: r.created_at,
      }));
    }
    return lsGet<InviteEntry[]>(LS.invites, []);
  },

  async create(entry: Omit<InviteEntry, 'id' | 'createdAt' | 'status'>): Promise<void> {
    if (supabase) {
      await supabase.from('collaboration_invites').insert({
        venue_name: entry.venueName, venue_pincode: entry.venuePincode,
        creator_id: entry.creatorId, creator_name: entry.creatorName,
        package_selected: entry.packageSelected, shoot_date: entry.shootDate,
        budget: entry.budget, message: entry.message,
      });
      return;
    }
    const list = lsGet<InviteEntry[]>(LS.invites, []);
    list.unshift({ ...entry, id: uid(), status: 'pending', createdAt: new Date().toISOString() });
    lsSet(LS.invites, list);
  },
};

// ─────────────────────────────────────────────────────────────
// UPI VERIFICATION SERVICE
// ─────────────────────────────────────────────────────────────

export const upiService = {
  async list(): Promise<UpiLog[]> {
    if (supabase) {
      const { data, error } = await supabase.from('upi_verifications').select('*').order('created_at', { ascending: false });
      if (error) return lsGet<UpiLog[]>(LS.upiLogs, []);
      return (data ?? []).map(r => ({
        id: r.id, brandName: r.brand_name ?? '', brandPhone: r.brand_phone ?? '',
        planTier: r.plan_tier, amount: r.amount, utrNumber: r.utr_number,
        status: r.status as UpiLog['status'], createdAt: r.created_at,
      }));
    }
    return lsGet<UpiLog[]>(LS.upiLogs, []);
  },

  async submit(log: Omit<UpiLog, 'id' | 'createdAt' | 'status'>): Promise<void> {
    if (supabase) {
      await supabase.from('upi_verifications').insert({
        brand_name: log.brandName, brand_phone: log.brandPhone,
        plan_tier: log.planTier, amount: log.amount, utr_number: log.utrNumber,
      });
      return;
    }
    const list = lsGet<UpiLog[]>(LS.upiLogs, []);
    list.unshift({ ...log, id: uid(), status: 'approved', createdAt: new Date().toISOString() });
    lsSet(LS.upiLogs, list);
  },
};
